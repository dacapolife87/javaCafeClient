package CafeClient;

public class CafeClient {

}
