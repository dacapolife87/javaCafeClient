package project_ver001;

import java.util.Scanner;

public class projectmain {
	public static void main(String[] args) {
		ClientPC cpc = new ClientPC();
		cpc.clientmain();
	}
}